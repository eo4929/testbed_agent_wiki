> hue을 off시킨다.

## Request

**Method**: `POST`

**URL**: `/resource/on`

**Auth**: `Required`

* Header
  * `USER-ID`: `Integer`, 요청하는 사용자의 아이디

**Parameters**: `None`

**Samples**:
```
curl -X POST http://143.248.41.173:8000/resource/off \
--header "USER-ID: {UserId}"
```

## Response

#### 200 Success Response
`String`, 스위치 off 성공여부에 대한 메시지
```
"[{\"success\":{\"/lights/2/state/on\":false}}]"
```
***
#### 401 Authentication Failed
`errorMessage`: `String`, 에러에 대한 메세지
```json
    {
      "errorMessage": "Authentication Failed."
    }
```
***
#### 401 Resource not bound
`errorMessage`: `String`, 에러에 대한 메세지
```json
    {
      "errorMessage": "Resource not bound."
    }
```
***
#### 409 Resource bound to another user
`errorMessage`: `String`, 에러에 대한 메세지
```json
    {
      "errorMessage": "Resource bound to another user."
    }
```
***
#### 400 Invalid action
`errorMessage`: `String`, 에러에 대한 메세지
```json
    {
      "errorMessage": "Invalid action."
    }
```
***
#### 400 Actuation failed
`errorMessage`: `String`, 에러에 대한 메세지
```json
    {
      "errorMessage": "Actuation failed."
    }
```